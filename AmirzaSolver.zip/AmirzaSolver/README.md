# Amirza Solver

حل‌کننده آفلاین کلمات فارسی مشابه آمیرزا با Kotlin + Jetpack Compose + MVVM.

## باز کردن
پروژه `AmirzaSolver` را در Android Studio باز کنید. JDK 17 را انتخاب کنید و Gradle Sync را اجرا کنید.

## Build Debug
از منوی Build گزینه Build APK(s) را بزنید یا در ترمینال:
`./gradlew assembleDebug`

APK در:
`app/build/outputs/apk/debug/app-debug.apk`

## نصب روی گوشی
USB debugging را فعال کنید و APK را نصب کنید:
`adb install -r app/build/outputs/apk/debug/app-debug.apk`

## Dictionary
فایل `app/src/main/assets/fa_dictionary.txt` است. هر خط یک کلمه است. می‌توانید آن را با Dictionary بزرگ‌تر جایگزین کنید؛ برنامه در اولین استفاده آن را در حافظه cache می‌کند.

## Release
برای APK ریلیز:
`./gradlew assembleRelease`
برای انتشار واقعی، در Android Studio یک signing key بسازید و signingConfigs را به build.gradle.kts اضافه کنید.

## تست
`./gradlew test`

## OCR / Screenshot / Floating
هسته Solver و UI پایه کامل و آفلاین است. قابلیت OCR و Overlay نیازمند اضافه‌کردن ماژول‌های Android/ML Kit و مجوز SYSTEM_ALERT_WINDOW است؛ این نسخه عمداً هیچ API خارجی یا سرور را برای حل کلمات مصرف نمی‌کند.
