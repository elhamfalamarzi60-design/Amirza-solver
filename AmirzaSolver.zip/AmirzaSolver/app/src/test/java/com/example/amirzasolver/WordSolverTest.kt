package com.example.amirzasolver
import org.junit.Assert.*
import org.junit.Test
class WordSolverTest {
 @Test fun madad(){ val s=WordSolver(listOf("مداد" to 40,"مادر" to 40,"داد" to 30,"دام" to 30,"ما" to 20)); val r=s.solve("مداد"); assertTrue(r.any{it.word=="مداد"}); assertFalse(r.any{it.word=="مادر"}) }
 @Test fun duplicateLetters(){ val s=WordSolver(listOf("سلام" to 40,"سسام" to 40,"سال" to 30)); val r=s.solve("سلام"); assertTrue(r.any{it.word=="سلام"}); assertFalse(r.any{it.word=="سسام"}) }
 @Test fun normalization(){ assertEquals("کیا",PersianNormalizer.normalize("كيأ")) }
}
