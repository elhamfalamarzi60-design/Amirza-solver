package com.example.amirzasolver
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{AmirzaTheme{CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl){MainScreen()}}}}
}
@Composable fun AmirzaTheme(content:@Composable()->Unit){MaterialTheme(colorScheme=if(isSystemInDarkTheme())darkColorScheme() else lightColorScheme(),content=content)}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun MainScreen(vm:SolverViewModel=viewModel()){
 val s by vm.state.collectAsState(); val clip=LocalClipboardManager.current
 Scaffold(topBar={TopAppBar(title={Text("Amirza Solver")})}){pad->
  Column(Modifier.padding(pad).padding(16.dp).fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally){
   Text("حروف مرحله را وارد کنید",style=MaterialTheme.typography.titleMedium)
   Spacer(Modifier.height(10.dp))
   OutlinedTextField(value=s.input,onValueChange=vm::setInput,label={Text("مثلاً: م د ا د یا مداد")},modifier=Modifier.fillMaxWidth(),singleLine=true)
   Spacer(Modifier.height(10.dp))
   Button(onClick=vm::solve,modifier=Modifier.fillMaxWidth()){Text("حل کن 🔍")}
   Spacer(Modifier.height(12.dp))
   Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf(0,2,3,4,5).forEach{n->FilterChip(selected=s.filter==n,onClick={vm.filter(n)},label={Text(if(n==0)"همه" else "$n حرفی")})}}
   Spacer(Modifier.height(12.dp))
   if(s.loading) CircularProgressIndicator()
   else LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxSize()){
    items(s.results){r->Card(Modifier.fillMaxWidth()){Row(Modifier.padding(12.dp).fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
     Column(Modifier.weight(1f)){Text(r.word,style=MaterialTheme.typography.titleMedium);Text("${r.word.length} حرف",style=MaterialTheme.typography.bodySmall)}
     IconButton(onClick={vm.remove(r.word)}){Icon(Icons.Default.Delete,"حذف")}
     IconButton(onClick={clip.setText(AnnotatedString(r.word))}){Icon(Icons.Default.ContentCopy,"کپی")}
    }}}
   }
  }
 }
}
private fun SolverViewModel.letRemoveHack(w:String){remove(w)}
