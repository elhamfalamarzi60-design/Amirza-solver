package com.example.amirzasolver
object PersianNormalizer {
    private val diacritics = Regex("[\\u064B-\\u065F\\u0670]")
    fun normalize(input: String): String = input
        .replace('ي','ی').replace('ى','ی').replace('ك','ک')
        .replace('ۀ','ه').replace('ة','ه').replace('أ','ا').replace('إ','ا').replace('ؤ','و')
        .replace("\u0640","")
        .replace("\u200C","")
        .replace("\u200D","")
        .replace(diacritics,"")
        .filter { it.isLetter() || it.isWhitespace() }
    fun letters(input: String): List<Char> = normalize(input).filter { it.isLetter() }.toList()
}