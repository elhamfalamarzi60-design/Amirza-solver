package com.example.amirzasolver
data class WordResult(val word:String,val score:Int)
class WordSolver(private val dictionary: List<Pair<String,Int>>) {
    fun solve(input: String, minLength:Int=2): List<WordResult> {
        val letters=PersianNormalizer.letters(input)
        val freq=letters.groupingBy{it}.eachCount()
        return dictionary.asSequence().filter { (w,_) ->
            w.length >= minLength && w.length <= letters.size && canBuild(w,freq)
        }.map { WordResult(it.first,it.second) }
        .sortedWith(compareByDescending<WordResult>{it.word.length}.thenByDescending{it.score}.thenBy{it.word})
        .toList()
    }
    private fun canBuild(word:String, freq:Map<Char,Int>):Boolean {
        val used=HashMap<Char,Int>()
        for(c in word) { val n=(used[c]?:0)+1; if(n>(freq[c]?:0)) return false; used[c]=n }
        return true
    }
}