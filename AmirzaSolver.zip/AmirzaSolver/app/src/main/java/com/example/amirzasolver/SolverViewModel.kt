package com.example.amirzasolver
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
data class SolverUiState(val input:String="",val results:List<WordResult> = emptyList(),val loading:Boolean=false,val filter:Int=0)
class SolverViewModel(app:Application):AndroidViewModel(app) {
    private val repo=DictionaryRepository(app)
    private val _state=MutableStateFlow(SolverUiState())
    val state:StateFlow<SolverUiState> = _state
    private var solver:WordSolver?=null
    init { viewModelScope.launch(Dispatchers.Default) { solver=WordSolver(repo.load()) } }
    fun setInput(s:String){_state.value=_state.value.copy(input=s)}
    fun solve(){ val input=_state.value.input; viewModelScope.launch(Dispatchers.Default){
        while(solver==null) kotlinx.coroutines.yield()
        val all=solver!!.solve(input,2)
        _state.value=_state.value.copy(results=all,loading=false)
    }; _state.value=_state.value.copy(loading=true) }
    fun filter(n:Int){_state.value=_state.value.copy(filter=n)}
    fun remove(word:String){_state.value=_state.value.copy(results=_state.value.results.filterNot{it.word==word})}
    fun visible():List<WordResult> = _state.value.results.filter{_state.value.filter==0 || it.word.length==_state.value.filter}
}