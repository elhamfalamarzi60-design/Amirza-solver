package com.example.amirzasolver
import android.content.Context
class DictionaryRepository(private val context: Context) {
    @Volatile private var cached: List<Pair<String,Int>>? = null
    fun load(): List<Pair<String,Int>> {
        cached?.let{return it}
        val list=mutableListOf<Pair<String,Int>>()
        context.assets.open("fa_dictionary.txt").bufferedReader().useLines { lines ->
            lines.map { PersianNormalizer.normalize(it).trim() }.filter { it.isNotEmpty() }.forEach { w ->
                val score = w.length * 10
                list += w to score
            }
        }
        return list.distinctBy{it.first}.also{cached=it}
    }
}